#!/usr/bin/env python3
"""
verify_all.py — EDEN Replication Kit: mechanical re-run harness.
Filed July 9, 2026. Part of `04 Simulations/Replication Kit (July 2026)/`.

WHAT THIS DOES (and nothing else):
  1. Discovers every sim folder under `04 Simulations/` that contains a committed
     engine (*.py, excluding *_PRE-FIX_archive*, make_figs*, __pycache__, and this
     kit) plus committed results*.json artifacts.
  2. For each engine: snapshots the ENTIRE sim folder (bytes + mtimes + sha256)
     to persistent staging, re-executes the engine in its own folder (fresh
     subprocess, default 300 s timeout), captures whichever results*.json files
     the run rewrote, compares fresh vs committed recursively (numeric tolerance
     1e-6 relative; keys containing 'timestamp'/'date' ignored, case-insensitive
     — ignored keys are LISTED so you can audit the ignoring), then RESTORES the
     folder to its committed state and verifies restoration with sha256 hashes.
     The vault is left byte-identical whether the sim reproduces or not.
     Snapshots persist on disk BEFORE execution and carry a DIRTY marker, so
     even a hard kill mid-run is recoverable: the next invocation restores any
     dirty folder before doing anything else.
  3. Emits `replication_report.json` next to this script and prints a console table.

CLASSIFICATION (honest, mechanical):
  REPRODUCES           ran clean; every rewritten results*.json matches committed
                       values within tolerance (byte-identical rewrites count).
  MISMATCH             ran clean; engine appears seeded but >=1 compared leaf differs.
  STOCHASTIC-UNSEEDED  ran clean; leaves differ AND the engine uses randomness with
                       no detectable seeding — nondeterminism, not necessarily error.
  NO-OUTPUT            ran clean but rewrote no results*.json (missing entry point,
                       arg-gated main, or writes elsewhere) — nothing to compare.
  ERROR / TIMEOUT      crashed, exited nonzero, or exceeded the timeout. stderr kept.
  NO-ENGINE            folder has committed results/SPEC but no eligible engine.
  NO-RESULTS-JSON      folder has an engine but no committed results*.json.

WHAT THIS DOES NOT DO: it does not judge whether the committed numbers are TRUE,
only whether the committed code regenerates the committed artifacts on this
machine. Semantic attack is your job; see `START HERE - Reviewer Guide.md`.

USAGE:
  python3 verify_all.py                 # full run (expect ~15-45 min)
  python3 verify_all.py --list          # discovery dry-run, no execution
  python3 verify_all.py --only v9       # substring filter on folder/engine name
  python3 verify_all.py --timeout 600   # per-engine timeout override
  python3 verify_all.py --budget 34     # stop starting engines after N seconds,
                                        # checkpoint, resume on next invocation
  python3 verify_all.py --finalize      # write the report from the checkpoint
  python3 verify_all.py --status        # show checkpoint progress

The --budget/--finalize machinery exists so the harness can run in short chunks
on execution environments that kill long processes; on a normal machine just run
it plain. State lives in `.staging/` next to this script and is deleted by
--finalize. If a run was interrupted, JUST RUN THE SCRIPT AGAIN — recovery of
any dirty folder is automatic and happens first.

Environment note: committed results came from the original authoring machine.
This harness records python/numpy/scipy/matplotlib versions in the report;
API-breakage failures (e.g., numpy 2.x removals) are reported as ERROR — an
environment finding, distinct from a values mismatch.
"""

import argparse
import hashlib
import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

KIT_DIR = Path(__file__).resolve().parent
SIM_ROOT = KIT_DIR.parent  # 04 Simulations/
# Staging holds the pre-run snapshots. Default: next to this script. Override
# with EDENREP_STAGING if your execution environment restricts the vault mount.
STAGING = Path(os.environ.get("EDENREP_STAGING", str(KIT_DIR / ".staging")))
PROGRESS = STAGING / "progress.json"
REPORT_PATH = KIT_DIR / "replication_report.json"
REPORT_DATE = "2026-07-09"

ENGINE_EXCLUDE = ("_PRE-FIX_archive", "make_figs", "verify_all")
RESULTS_GLOB = "results*.json"
DEFAULT_TIMEOUT = 300
MAX_TIMEOUT_ATTEMPTS = 2  # constrained-budget timeouts get one fresh retry

IGNORE_KEY_PAT = re.compile(r"(timestamp|date)", re.IGNORECASE)
RANDOM_PAT = re.compile(
    r"(np\.random\.|numpy\.random|default_rng|RandomState"
    r"|(?<![\w.])random\.(random|randint|choice|shuffle|gauss|uniform|sample|normal))"
)
SEED_PAT = re.compile(
    r"(np\.random\.seed\s*\(|(?<![\w.])random\.seed\s*\(|default_rng\s*\(\s*[A-Za-z_0-9]"
    r"|RandomState\s*\(\s*[0-9]|SEED\s*=\s*[0-9]|seed\s*=\s*[0-9])"
)

PROVENANCE_NOTES = [
    "EVE Sim v1: during kit construction (July 9, 2026, pre-harness timing probe) "
    "eve_sim_v1.py was executed once WITHOUT snapshot protection, regenerating "
    "results.json and fig1-fig4. The engine is seeded; every regenerated value "
    "matches the published RESULTS write-up at all quoted precision (month-16/20/74 "
    "failure timing; 62.1%/84.4% concentration; 17.35% addictive share; 53.8%/45.5% "
    "royalty flattening). Continuity of deep decimals and PNG bytes with the "
    "original June-12 artifacts cannot be re-verified and is disclosed here rather "
    "than papered over. All other executions went through snapshot-restore with "
    "hash verification.",
]


# ---------- discovery ----------

def eligible_engine(p: Path) -> bool:
    if p.suffix != ".py":
        return False
    if "__pycache__" in p.parts:
        return False
    return not any(tok in p.name for tok in ENGINE_EXCLUDE)


def discover():
    out = []
    for folder in sorted(SIM_ROOT.iterdir(), key=lambda p: p.name.lower()):
        if not folder.is_dir() or folder == KIT_DIR or folder.name == "__pycache__":
            continue
        engines = sorted(p for p in folder.glob("*.py") if eligible_engine(p))
        results = sorted(
            p for p in folder.glob(RESULTS_GLOB) if "_PRE-FIX_archive" not in p.name
        )
        out.append((folder, engines, results))
    return out


# ---------- snapshot / restore (persistent, crash-safe) ----------

def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def walk_files(folder: Path):
    for p in sorted(folder.rglob("*")):
        if p.is_file():
            yield p


def robust_rmtree(path: Path):
    """rmtree that degrades gracefully on restrictive mounts: stdlib first,
    then `rm -rf`, then rename-out-of-the-way. Never raises."""
    if not path.exists():
        return
    try:
        shutil.rmtree(path)
        return
    except OSError:
        pass
    try:
        subprocess.run(["rm", "-rf", str(path)], check=True, capture_output=True)
        if not path.exists():
            return
    except (OSError, subprocess.CalledProcessError):
        pass
    try:
        trash = path.parent / f"_trash_{int(time.time()*1000)}"
        path.rename(trash)
        print(f"  note: could not delete {path.name}; parked at {trash.name}",
              flush=True)
    except OSError as e:
        print(f"  note: could not delete or park {path}: {e}", flush=True)


def safe_name(folder: Path) -> str:
    return re.sub(r"[^A-Za-z0-9._-]+", "_", folder.name)


def stage_dir(folder: Path) -> Path:
    return STAGING / safe_name(folder)


def snapshot(folder: Path):
    """Persist a full copy of folder into staging with a DIRTY marker.
    Returns the manifest."""
    sd = stage_dir(folder)
    robust_rmtree(sd)
    files_dir = sd / "files"
    manifest = {"folder": str(folder), "files": {}}
    for p in walk_files(folder):
        rel = p.relative_to(folder)
        dest = files_dir / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dest)
        st = p.stat()
        manifest["files"][str(rel)] = {
            "sha": sha256_file(p), "mtime_ns": st.st_mtime_ns
        }
    with open(sd / "manifest.json", "w") as f:
        json.dump(manifest, f)
    (sd / "DIRTY").write_text("engine running or interrupted; restore me first\n")
    return manifest


def restore(folder: Path, manifest: dict):
    """Force folder back to snapshot state. Returns anomaly strings."""
    sd = stage_dir(folder)
    files_dir = sd / "files"
    anomalies = []
    current = {str(p.relative_to(folder)): p for p in walk_files(folder)}
    for rel, p in current.items():
        if rel not in manifest["files"]:
            try:
                p.unlink()
            except OSError as e:
                anomalies.append(f"could not delete created file {rel}: {e}")
    for d in sorted((p for p in folder.rglob("*") if p.is_dir()), reverse=True):
        rel_prefix = str(d.relative_to(folder)) + os.sep
        if not any(r.startswith(rel_prefix) for r in manifest["files"]):
            try:
                d.rmdir()  # only succeeds if empty
            except OSError:
                pass
    for rel, meta in manifest["files"].items():
        live = folder / rel
        src = files_dir / rel
        if (not live.exists()) or sha256_file(live) != meta["sha"]:
            live.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, live)
        st = live.stat()
        if st.st_mtime_ns != meta["mtime_ns"]:
            os.utime(live, ns=(meta["mtime_ns"], meta["mtime_ns"]))
    return anomalies


def verify_restore(folder: Path, manifest: dict):
    problems = []
    live = {str(p.relative_to(folder)) for p in walk_files(folder)}
    for rel in live:
        if rel not in manifest["files"]:
            problems.append(f"extra file after restore: {rel}")
    for rel, meta in manifest["files"].items():
        p = folder / rel
        if not p.exists():
            problems.append(f"missing file after restore: {rel}")
        elif sha256_file(p) != meta["sha"]:
            problems.append(f"hash mismatch after restore: {rel}")
    return (not problems), problems


def clear_stage(folder: Path):
    robust_rmtree(stage_dir(folder))


def recover_dirty():
    """Restore any folder whose previous run was interrupted. Runs first, always."""
    if not STAGING.exists():
        return
    for sd in sorted(STAGING.iterdir()):
        if not sd.is_dir() or not (sd / "DIRTY").exists():
            continue
        try:
            with open(sd / "manifest.json") as f:
                manifest = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            print(f"!! dirty stage {sd.name} unreadable: {e}", flush=True)
            continue
        folder = Path(manifest["folder"])
        print(f"[recovering      ] {folder.name} (interrupted run)", flush=True)
        restore(folder, manifest)
        ok, problems = verify_restore(folder, manifest)
        if ok:
            robust_rmtree(sd)
            print(f"[recovered OK    ] {folder.name}", flush=True)
        else:
            print(f"!! recovery incomplete for {folder.name}: {problems}", flush=True)


# ---------- recursive JSON comparison ----------

def is_number(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def num_close(a, b, rel_tol=1e-6):
    if math.isnan(a) and math.isnan(b):
        return True
    if math.isinf(a) or math.isinf(b):
        return a == b
    return math.isclose(a, b, rel_tol=rel_tol, abs_tol=1e-9)


def compare_json(ref, fresh, path, ctx):
    if isinstance(ref, dict) and isinstance(fresh, dict):
        for k in sorted(set(ref) | set(fresh)):
            kpath = f"{path}.{k}" if path else str(k)
            if IGNORE_KEY_PAT.search(str(k)):
                ctx["skipped"].add(str(k))
                continue
            if k not in ref:
                ctx["mismatches"].append(f"{kpath} <only-in-fresh>")
            elif k not in fresh:
                ctx["mismatches"].append(f"{kpath} <only-in-committed>")
            else:
                compare_json(ref[k], fresh[k], kpath, ctx)
    elif isinstance(ref, list) and isinstance(fresh, list):
        if len(ref) != len(fresh):
            ctx["mismatches"].append(f"{path} <length {len(ref)} vs {len(fresh)}>")
        for i, (r, f) in enumerate(zip(ref, fresh)):
            compare_json(r, f, f"{path}[{i}]", ctx)
    elif is_number(ref) and is_number(fresh):
        ctx["compared"] += 1
        if not num_close(ref, fresh):
            ctx["mismatches"].append(f"{path} ({ref!r} -> {fresh!r})")
    else:
        ctx["compared"] += 1
        if type(ref) is not type(fresh) or ref != fresh:
            ctx["mismatches"].append(f"{path} ({ref!r} -> {fresh!r})")


def compare_files(committed: Path, fresh: Path):
    ctx = {"mismatches": [], "skipped": set(), "compared": 0}
    try:
        with open(committed) as f:
            ref = json.load(f)
        with open(fresh) as f:
            new = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        ctx["mismatches"].append(f"<unreadable: {e}>")
        return ctx
    compare_json(ref, new, "", ctx)
    return ctx


# ---------- seeding heuristic ----------

def seeding_class(engine: Path) -> str:
    try:
        src = engine.read_text(errors="replace")
    except OSError:
        return "unknown"
    if not RANDOM_PAT.search(src):
        return "deterministic"
    return "seeded" if SEED_PAT.search(src) else "unseeded-random"


# ---------- checkpoint ----------

def load_progress():
    if PROGRESS.exists():
        try:
            with open(PROGRESS) as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            pass
    return {"completed": {}, "attempts": {}, "order": {}}


def save_progress(prog):
    STAGING.mkdir(exist_ok=True)
    tmp = PROGRESS.with_suffix(".tmp")
    with open(tmp, "w") as f:
        json.dump(prog, f, indent=1)
    tmp.replace(PROGRESS)


# ---------- engine execution ----------

def run_engine(folder: Path, engine: Path, results: list, timeout: int):
    entry = {
        "sim_folder": folder.name,
        "engine": engine.name,
        "seeding": seeding_class(engine),
        "status": None,
        "runtime_s": None,
        "returncode": None,
        "timeout_used_s": timeout,
        "files": [],
        "mismatched_leaves": 0,
        "restore_verified": None,
        "notes": [],
    }
    manifest = snapshot(folder)
    env = dict(os.environ, MPLBACKEND="Agg")
    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            [sys.executable, engine.name],
            cwd=str(folder), env=env,
            capture_output=True, text=True, timeout=timeout,
        )
        entry["runtime_s"] = round(time.monotonic() - t0, 1)
        entry["returncode"] = proc.returncode
        if proc.returncode != 0:
            entry["status"] = "ERROR"
            entry["notes"].append("nonzero exit")
            entry["stderr_tail"] = proc.stderr[-900:]
    except subprocess.TimeoutExpired:
        entry["runtime_s"] = round(time.monotonic() - t0, 1)
        entry["status"] = "TIMEOUT"
        entry["notes"].append(f"exceeded {timeout}s")
    except OSError as e:
        entry["runtime_s"] = round(time.monotonic() - t0, 1)
        entry["status"] = "ERROR"
        entry["notes"].append(f"could not execute: {e}")

    total_mm = 0
    any_rewritten = False
    if entry["status"] is None:
        for res in results:
            rel = str(res.relative_to(folder))
            meta = manifest["files"].get(rel)
            frec = {"file": res.name, "rewritten": False}
            if meta is None:
                frec["note"] = "not present at snapshot (unexpected)"
                entry["files"].append(frec)
                continue
            if not res.exists():
                frec.update(note="deleted by run", rewritten=True)
                total_mm += 1
                any_rewritten = True
                entry["files"].append(frec)
                continue
            touched = res.stat().st_mtime_ns != meta["mtime_ns"]
            changed = sha256_file(res) != meta["sha"]
            if not touched and not changed:
                frec["note"] = "not rewritten by this engine"
                entry["files"].append(frec)
                continue
            any_rewritten = True
            frec["rewritten"] = True
            if not changed:
                frec["byte_identical"] = True
                frec["mismatches"] = 0
            else:
                frec["byte_identical"] = False
                ctx = compare_files(stage_dir(folder) / "files" / rel, res)
                frec["compared_leaves"] = ctx["compared"]
                frec["mismatches"] = len(ctx["mismatches"])
                frec["mismatched_paths"] = ctx["mismatches"][:20]
                frec["ignored_keys"] = sorted(ctx["skipped"])[:20]
                total_mm += len(ctx["mismatches"])
            entry["files"].append(frec)
        for p in folder.glob(RESULTS_GLOB):
            rel = str(p.relative_to(folder))
            if rel not in manifest["files"] and "_PRE-FIX_archive" not in p.name:
                entry["notes"].append(f"run created uncommitted results file: {p.name}")

        entry["mismatched_leaves"] = total_mm
        if not any_rewritten:
            entry["status"] = "NO-OUTPUT"
        elif total_mm == 0:
            entry["status"] = "REPRODUCES"
        elif entry["seeding"] == "unseeded-random":
            entry["status"] = "STOCHASTIC-UNSEEDED"
        else:
            entry["status"] = "MISMATCH"

    anomalies = restore(folder, manifest)
    ok, problems = verify_restore(folder, manifest)
    if not ok:
        restore(folder, manifest)
        ok, problems = verify_restore(folder, manifest)
    entry["restore_verified"] = ok
    if anomalies:
        entry["notes"].extend(anomalies)
    if not ok:
        entry["notes"].extend(problems)
        print(f"  !! RESTORE FAILED {folder.name}/{engine.name}: {problems}", flush=True)
    else:
        clear_stage(folder)
    return entry


# ---------- report ----------

def _ver(mod):
    try:
        return __import__(mod).__version__
    except Exception:
        return None


def write_report(prog, timeout):
    entries = sorted(prog["completed"].values(),
                     key=lambda e: prog["order"].get(
                         f"{e['sim_folder']}::{e.get('engine')}", 999))
    counts = {}
    for e in entries:
        counts[e["status"]] = counts.get(e["status"], 0) + 1
    report = {
        "report_date": REPORT_DATE,
        "generated_by": "verify_all.py (Replication Kit, July 2026)",
        "machine_wall_clock": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "numpy": _ver("numpy"), "scipy": _ver("scipy"),
            "matplotlib": _ver("matplotlib"),
        },
        "tolerance": {"relative": 1e-6, "absolute": 1e-9,
                      "ignored_key_pattern": IGNORE_KEY_PAT.pattern},
        "timeout_s_default": timeout,
        "status_counts": counts,
        "all_restores_verified": all(e.get("restore_verified", True)
                                     for e in entries),
        "provenance_notes": PROVENANCE_NOTES,
        "entries": entries,
    }
    with open(REPORT_PATH, "w") as f:
        json.dump(report, f, indent=2)
    return report, entries, counts


def print_table(entries, counts, all_ok):
    w = max(len(e["sim_folder"] + " :: " + (e.get("engine") or "-"))
            for e in entries)
    print("\n" + "=" * (w + 46))
    print(f"{'sim :: engine':<{w}}  {'reproduces':<22} {'mm-keys':>7} {'runtime':>9}")
    print("-" * (w + 46))
    for e in entries:
        name = e["sim_folder"] + " :: " + (e.get("engine") or "-")
        s = e["status"]
        rep = ("YES" if s == "REPRODUCES" else
               "no (" + s.lower() + ")" if s in ("MISMATCH", "STOCHASTIC-UNSEEDED")
               else s.lower())
        rt = f"{e['runtime_s']}s" if e.get("runtime_s") is not None else "-"
        print(f"{name:<{w}}  {rep:<22} {e['mismatched_leaves']:>7} {rt:>9}")
    print("-" * (w + 46))
    print("counts:", json.dumps(counts))
    print(f"all restores verified byte-identical: {all_ok}")
    print(f"report: {REPORT_PATH}")


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser(description="EDEN mechanical re-run harness")
    ap.add_argument("--only", default=None)
    ap.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    ap.add_argument("--budget", type=int, default=None,
                    help="wall-clock budget (s); checkpoint and resume")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--finalize", action="store_true")
    ap.add_argument("--status", action="store_true")
    args = ap.parse_args()

    sims = discover()

    if args.list:
        for folder, engines, results in sims:
            print(folder.name)
            for e in engines:
                print(f"    engine: {e.name} [{seeding_class(e)}]")
            for r in results:
                print(f"    committed: {r.name}")
        return

    recover_dirty()
    prog = load_progress()

    # Build the full work list in stable order.
    work = []   # (key, folder, engine|None, results, kind)
    idx = 0
    for folder, engines, results in sims:
        if not engines:
            key = f"{folder.name}::None"
            work.append((key, folder, None, results, "NO-ENGINE"))
            prog["order"].setdefault(key, idx); idx += 1
            continue
        if not results:
            key = f"{folder.name}::{', '.join(e.name for e in engines)}"
            work.append((key, folder, None, results, "NO-RESULTS-JSON"))
            prog["order"].setdefault(key, idx); idx += 1
            continue
        for engine in engines:
            key = f"{folder.name}::{engine.name}"
            work.append((key, folder, engine, results, "RUN"))
            prog["order"].setdefault(key, idx); idx += 1

    if args.status:
        done = sum(1 for k, *_ in work if k in prog["completed"])
        print(f"{done}/{len(work)} engines complete")
        for k, *_ in work:
            state = prog["completed"].get(k, {}).get("status", "PENDING")
            print(f"  [{state:<18}] {k}")
        return

    if not args.finalize:
        t_start = time.monotonic()
        for key, folder, engine, results, kind in work:
            if key in prog["completed"]:
                continue
            if args.only and args.only.lower() not in key.lower():
                continue
            elapsed = time.monotonic() - t_start
            if args.budget and elapsed > args.budget - 10:
                print(f"[budget reached  ] checkpointing at {elapsed:.0f}s", flush=True)
                break
            if kind == "NO-ENGINE":
                prog["completed"][key] = {
                    "sim_folder": folder.name, "engine": None,
                    "status": "NO-ENGINE", "runtime_s": 0.0,
                    "mismatched_leaves": 0, "restore_verified": True,
                    "notes": [f"{len(results)} committed results*.json, no eligible *.py"
                              if results else "no eligible *.py (SPEC-only folder)"],
                    "files": [r.name for r in results],
                }
                save_progress(prog)
                print(f"[NO-ENGINE       ] {folder.name}", flush=True)
                continue
            if kind == "NO-RESULTS-JSON":
                prog["completed"][key] = {
                    "sim_folder": folder.name, "engine": key.split("::", 1)[1],
                    "status": "NO-RESULTS-JSON", "runtime_s": 0.0,
                    "mismatched_leaves": 0, "restore_verified": True,
                    "notes": ["engine committed but no results*.json to compare"],
                    "files": [],
                }
                save_progress(prog)
                print(f"[NO-RESULTS-JSON ] {folder.name}", flush=True)
                continue

            timeout_eff = args.timeout
            if args.budget:
                remaining = args.budget - (time.monotonic() - t_start) - 6
                timeout_eff = max(5, min(args.timeout, int(remaining)))
            print(f"[running         ] {folder.name} :: {engine.name} "
                  f"(timeout {timeout_eff}s)", flush=True)
            entry = run_engine(folder, engine, results, timeout_eff)

            attempts = prog["attempts"].get(key, 0) + 1
            prog["attempts"][key] = attempts
            constrained = timeout_eff < args.timeout
            if (entry["status"] == "TIMEOUT" and constrained
                    and attempts < MAX_TIMEOUT_ATTEMPTS):
                # budget-constrained timeout: leave pending for a fresh-budget retry
                print(f"[retry queued    ] {key} (constrained timeout "
                      f"{timeout_eff}s < {args.timeout}s)", flush=True)
                save_progress(prog)
                continue
            if entry["status"] == "TIMEOUT" and constrained:
                entry["notes"].append(
                    f"environment ceiling: this execution environment kills "
                    f"processes at ~{timeout_eff}s; the registered {args.timeout}s "
                    f"budget could not be granted. Re-run on an unrestricted "
                    f"machine before treating this as non-reproducible.")
                entry["environment_ceiling"] = True
            prog["completed"][key] = entry
            save_progress(prog)
            print(f"[{entry['status']:<16}] {key} ({entry['runtime_s']}s, "
                  f"{entry['mismatched_leaves']} mismatched leaves, "
                  f"restore={'OK' if entry['restore_verified'] else 'FAILED'})",
                  flush=True)

    pending = [k for k, *_ in work if k not in prog["completed"]]
    if pending and not args.finalize:
        print(f"\n{len(work) - len(pending)}/{len(work)} complete; "
              f"{len(pending)} pending — run again to continue.")
        save_progress(prog)
        return

    if pending:
        print(f"finalize requested with {len(pending)} pending entries: {pending}")

    report, entries, counts = write_report(prog, args.timeout)
    print_table(entries, counts, report["all_restores_verified"])
    # clean staging on a complete finalize
    if not pending and STAGING.exists():
        dirty = [d for d in STAGING.iterdir()
                 if d.is_dir() and (d / "DIRTY").exists()]
        if not dirty:
            robust_rmtree(STAGING)


if __name__ == "__main__":
    main()
