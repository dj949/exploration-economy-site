# START HERE — Out-of-Family Reviewer Guide

*The EDEN simulation program's own top-priority action item is **out-of-family human replication**: every score in this vault carries an "in-family discount" because AI built and reviewed the work. This kit exists to make your attack cheap. It is written to help you break things, not admire them. — July 9, 2026*

---

## What this program claims — and, louder, what it does NOT

EDEN is a proposed economy where currency mints only from verified human engagement (machines/institutions pay), digital assets are free to use, creators are paid by use, and a floor guarantees essentials. The modeling program tests whether the mechanism survives contact with adversaries and reality.

**The honest brand is built on retired claims.** Read this list first — it is the fastest way to calibrate trust. Each was once asserted, then **retired in writing** when evidence wouldn't carry it (the program's standing move: *protect the human core, retire the maximalist shell*):

- ~~"Self-funding floor"~~ → retired; the floor needs a funder (governments buying welfare delivery ~26% cheaper).
- ~~"≈0% inflation"~~ → retired; replaced by an exchange-rate/governor framing.
- ~~"Effort-weighting defeats addictive farming (~2.5×)"~~ → retired as a static-adversary artifact (v8); replaced by outcome-linked minting + private audit.
- ~~"Equal floor everywhere from day one"~~ → retired (v5.4); replaced by "universal in guarantee, converging in strength," transfers capped at a consent bar.
- ~~"Reflexivity gives only a ~26% dip"~~ → retired (v9); under a levered cross-venue run the *price crashes*; the claim is now "protect people, concede price."
- ~~"A biometric breach is unrecoverable"~~ → reframed (v10); breach-survivable by design, with the liveness arms race named as unsolved.

**What it does NOT claim:** that it's proven in the wild; that identity/liveness against synthetic humans is solved (it is not — the keystone open problem); that institutions will pay for data/code (untested — the true hinge); that it should replace the internet or capitalism (it's an overlay and a parallel lane). If you find yourself attacking a maximalist claim, check whether it was already retired — the interesting frontier is the *core* that survived.

## The 5 highest-value attack surfaces (spend your time here)

1. **Proof-of-personhood / liveness at scale.** Every sim that matters *assumes* the identity layer holds (detection efficacy, forgery cost, liveness are exogenous dials). If real-world personhood is cheaper to forge than assumed, v11 (validator sortition), v12 (aggregator audit), and the whole floor degrade together. This is the keystone; attack it first. See `ASSUMPTIONS LEDGER` §identity.
2. **Real willingness-to-pay for data AND code.** The floor's funding, the builder economy, and machine-pay all rest on institutions actually paying. No sim can supply this number; it's a field experiment (a WTP experiment design is a standing next step). If WTP is near zero, the economic case narrows to the data-dignity layer.
3. **The EBI oracle under a live, funded adversary.** The price index that the floor and machine-pay are denominated in is only modeled statistically (a v13 Oracle Capture SPEC is registered but not yet run). A captured oracle corrupts every downstream number.
4. **"Honest mechanism, captured input."** The program's own recurring failure pattern: a defense works as specified but trusts a corrupted input (the effort classifier scored an engineered interaction; the grocery door paid a crashed market rate). Audit the *inputs* to every mechanism, not the mechanism.
5. **In-family evidence itself.** Everything here is AI-built and AI-reviewed. The registered bars, archived originals, and this reproduction harness are designed to make that *checkable* — but checkable is not the same as *checked by a hostile human*. That's you.

## Run the reproduction harness (≈10 minutes)

```
cd "04 Simulations/Replication Kit (July 2026)"
python3 verify_all.py          # re-runs every committed engine, compares to committed JSON
```

It discovers every sim folder, re-executes its engine in place, compares the fresh output to the committed `results*.json` at 1e-6 tolerance, and **restores the committed files byte-identically** (verified by hash — it leaves your vault untouched). Output: `replication_report.json` + a console table.

**Our run (July 9, 2026) — the honest reproduction ledger (52 engines):**

- **44 REPRODUCE** to 1e-6. This is the load-bearing number.
- **8 exceptions, all benign and explained, zero value contradictions:**
  - 2 **SPEC-only** folders (v13 Oracle, v13 Ecology top-level) — registered bars, engine not yet written.
  - 1 **results-pending** (v13 Ecology engine existed but hadn't produced JSON at harness time; it has since — re-run to reclassify).
  - 3 **"mismatch"** that are *not* value contradictions: `scale_check_1M` differs only in a self-timing field (`runtime_s 4.6→4.9`); `eve_sim_v6_5` and `v6_6` differ only in `<only-in-fresh>` keys (the engines gained `payr`/param fields *after* their JSON was frozen — additive schema drift, no changed values).
  - 1 **timeout** (`world_model_sim`, v5) — the sandbox kills processes at ~25s; the engine needs the registered 300s budget. Re-run on an unrestricted machine.
  - 1 **no-baseline** (`eve_sim_v6_8`) — it was being created during the harness run; now committed.

If you get materially different numbers on unrestricted hardware, **that is a finding and we want it** — file it against the specific `results*.json` key.

**Verification-pass update (July 9, 2026, evening — the ledger above is superseded for coverage; see `replication_report_verification_v3_2026-07-09.json` in this folder):** a fresh, independent session re-ran the full harness over all **54** engines (the four built after the 17:00 report — oracle, v14, v15 — plus v6.8 against its now-committed baseline): **49 REPRODUCE**; the 4 mismatches are the same benign classes as above plus one *real bug found and fixed* — `composition_sim.py` hardcoded the authoring machine's absolute path, silently blanking its X0 anchors anywhere else (fixed July 9, path now derived from the file's own location; patched output verified leaf-identical to committed). The `world_model_sim` timeout was also resolved out-of-band: run standalone (32s) it reproduces **8 of 9** results files exactly; the ninth differed in one leaf (`results_world_mature.json → world_floor_cost_share_end` 8.02 → 7.95, ~0.9%) — a v5-era engine-evolution drift, same class as v6_5/v6_6. **RESOLVED July 11, 2026 (Backlog #5, Opus 4.8): the baseline was regenerated under the current engine — this stale leaf is now 7.95 in the committed JSON, the other 8 files unchanged, and `world_model_sim` now reproduces 9/9. The known exception is retired** (the value is cited in no claim; regenerating was preferred over a permanent asterisk on the reproduction ledger). Today's five sims were additionally re-executed outside the harness (v13-Ecology fully from scratch: 346,963 leaves, zero mismatches). The Oracle engine's O0 gate was strengthened to enforce its registered closed-form comparison and re-emitted (only `O0` fields changed, disclosed in its RESULTS). **Environment floor for replicators: python ≥3.10, numpy, scipy, matplotlib** (two engines import scipy; without it they ERROR — an environment finding, not a values finding). Full narrative: vault root, `VERIFICATION v3`.

**Verification-pass update (July 10–11, 2026 — coverage extended to v16–v30; ledger: `replication_report_verification_v4_2026-07-10.json` in this folder):** a fresh Fable 5 session independently re-executed **every engine created after v3's ledger** — v16 through v30, the theory-proofs engine, and the rewritten proving-cost envelope — in isolated scratch copies (Python 3.10.12, numpy 2.2.6): **all reproduce**, byte-identically wherever figures/JSONs were committed (v17–v19, v22–v30 including every PNG), and to 0 mismatched leaves elsewhere (v20: 33, v21: 61, proofs: 178, envelope: 195). Two in-place mutations of older artifacts were investigated and are value-neutral (v9's July-9 rewrite: byte-identical to a fresh run + both pre-mutation attestations; the envelope's July-9 rewrite: 195/195 leaves unchanged, `headline_derivation` added — now disclosed in its own folder). The same pass then executed the v4 action list — re-scoring three bars to their registered forms (v17 C3 → FAIL, v22 T5 → FAIL, v24 M1/A5 misreport corrected), committing previously-uncommitted evidence (v16 isolation slices, v19 registered sweep + two labeled extensions, v20 registered-dial probe, v29 gate-binding probe, dashboard baselines + generator), and reconciling the proofs record to one story — after which **every modified engine was re-run and re-verified** (pre-existing leaves unchanged except the disclosed re-scores; see the v4 ledger's `post_correction` entries). The full-vault `verify_all.py` refresh on the owner's machine remains owed (this sandbox kills long processes; the .staging debris from the July 10 in-vault attempt should be deleted in Finder). Full narrative: vault root, `VERIFICATION v4`.

## Suggested 2-day replication plan

**Day 1 — mechanical + spot-check.** Run `verify_all.py`. Then open `CLAIMS REGISTER` and pick 5 headline claims; trace each to its JSON key and confirm the number. Read `ASSUMPTIONS LEDGER` end to end (it's the map of soft spots).

**Day 2 — adversarial deep-dive.** Pick **two** sims from surfaces 1–3 above. For each: read its registered SPEC (bars were fixed before code — check the git/file dates and the "registered before code" claim), read its engine, and attack the model's *assumptions* (not its arithmetic — the arithmetic reproduces). Ask the six playbook questions (`FRONTIER HANDOFF` C.1): does it trust an input it doesn't control? static vs adaptive adversary? "by construction" tells? off-protocol flank? correlated failure? transparent-and-learned? Write what you find as a finding against a named artifact.

## House rules you can hold us to

Pre-register bars before running; never move a bar after a run (post-hoc fixes are labeled and re-registered); archive originals (`*_PRE-FIX_archive`); every headline traces to a committed artifact; failures are reported as findings. If you find a bar that moved, a headline with no artifact, or a silent overwrite, that is a serious finding — the whole epistemic claim of this program rests on those five rules.

---

*Companions in this kit: `verify_all.py` (+ `replication_report.json`), `CLAIMS REGISTER - Every Headline and Its Artifact.md`, `ASSUMPTIONS LEDGER - Every Dial a Skeptic Should Attack.md`. Compiled by Claude Fable 5, July 9, 2026 — itself in-family, and therefore not a substitute for you.*
