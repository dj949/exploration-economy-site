# ECONOMIST BRIEF — Start Here

### A self-contained handoff for a professional economist engaged to attack this work

*July 9, 2026. This is the one file to read first — everything else it references lives in the same vault, but this brief is written to stand alone. It was compiled by the AI models that built the work; that fact is itself the reason you're being handed it (see §6).*

---

## 1. What you're looking at, in one paragraph

EDEN is a designed parallel economy: a currency (EVE) minted only by verified humans' engaged attention to real digital work, a guaranteed essentials floor indexed to a measured basket (the EBI) rather than to the currency, machine/corporate actors paying fiat to participate, non-transferable income streams (no dynastic compounding), and a ledger governed by sortition juries of verified persons plus a two-house structure (one-person-one-vote + contribution-weighted-with-caps). It is explicitly **not** claiming to replace fiat as unit of account (promises are denominated in goods; dollars remain the pricing language at the interface — see `01 Canon/Monetary Position Note`), and its floor **never prints** (delivery is staged to funding; the failure mode is honest rationing, not inflation finance — see `01 Canon/Incidence Note` for the full who-pays chain).

## 2. What has actually been done (and how much to trust it)

- **34 simulation engine-runs (v1–v34) + machine-checked proofs** (2025–2026; "~16 waves" when first drafted — roughly doubled in the July 9–11 sprint; several carry lettered sub-waves — v4b, v5.1–5.4, v6.0–6.8, v8.1 — and there are two distinct v13 engines, Oracle and Ecology): pass/fail bars fixed in writing *before* each engine was coded; failures published as failures; three full public redesigns forced by the design's own tests. The map is `04 Simulations/00 INDEX - Simulations Overview.md`; every headline traces to a committed `results*.json` via `04 Simulations/Replication Kit (July 2026)/CLAIMS REGISTER`.
- **Mechanical reproducibility is verified, not asserted:** a re-run harness (`verify_all.py`) regenerates 49 of 54 engines to 1e-6 from the code on disk; the exceptions are individually explained (schema drift, one self-timing field, one fixed path bug). Two independent same-day verification passes exist (`VERIFICATION v2`, `VERIFICATION v3`, vault root).
- **The load-bearing algebra is machine-checked** (sympy/exact-rational): taper no-cliff, committee hypergeometrics to the last digit, cap-function properties, closed forms vs Monte Carlo (`04 Simulations/Proofs - Machine-Checked Theory Claims`).
- **A joint sensitivity sweep (Lucas-critique instrument) already demoted one headline:** the federation *storm* result holds in only 47% of a ±50% joint dial envelope — it is conditional on sponsors paying ≥~50% of obligations during recessions, now a proposed contract term rather than an assumption (`EVE Sim v16`). The peacetime, governance, and committee results survived the same shaking.
- **Honest failures on the record, kept as failures:** the consent bar at world scale (rich-region transfers ~25% of regional mint vs ~6% political tolerance — the design's own fiscal-federalism problem, measured); the ecology model (failed its own sanity gate, filed PROVISIONAL, root-caused, rebuild owed); oracle re-validation speed (0.888 vs 0.90 bar); the "26% cheaper than welfare" number compressing to ~9% for a mid-storm backstop; a governance cap that leaked 9.4% as first written (fixed, disclosed).

**Trust model:** treat every result as *mechanism-existence under stated dials* — "this rule closes this exploit; removing it reopens it" — never as a forecast. The dials are enumerated with sweep ranges in `Replication Kit/ASSUMPTIONS LEDGER`.

## 3. The economics arguments, pre-run against ourselves

`03 White Paper/EDEN Red-Team — The Economics Literature vs EDEN` argues the ten strongest published objections at full strength (Lucas, Hayek/calculation, index-number bias, Goodhart, Myerson–Satterthwaite incidence, first-generation crisis models, OCA/fiscal federalism, unit-of-account inertia, the data-valuation gap, Baumol) and scores them honestly: **four answered at strength (A4, A6, A7, A9), five partial (A1, A2, A5, A8, A10), one originally unanswered (A3, index-number bias)**. A3 has since moved to **partial** — the EBI Methodology Spec specifies the composition-governance half, and `EVE Sim v33` (Index Drift) shows the fixed 0.05 bias budget is insufficient against systematic drift and needs a ≤~2.5-yr re-basing rule (a canon candidate). **Your first task could simply be: grade that document.** Where it steelmans poorly, say so; where the canon answer is weaker than claimed, that's a finding.

> **Read this before the sims (added July 11, 2026):** a full verification pass (`VERIFICATION v4`, July 10–11) re-executed every engine added July 9–10 and **re-scored several results downward** — the current record is the post-correction one. If you see earlier numbers circulating, these supersede them: v17's basket rate-cap **fails as registered** (food/shelter $21.6M vs the $20M bar; defenses-off capture is ~12,400×, not ~5,000×); v22's influence catch-up **fails its 10-year bar** (0.78 vs 0.80; met at ~12 years); v19's "88% gone" claim was an inversion (88% *retained*) — the extreme cell has since been genuinely run and passes; the proofs artifact is **10/10 with grade labels** (P8 is self-consistency, not independent re-derivation); v16's austerity threshold is seed-split at 0.50 (v31 then killed the escrow alternative; recommendation ≥0.60); and the ecology model's floor is now **RESOLVED-NEGATIVE — structurally unfundable at registered dials** (v13.1, regression-gated), forcing a purse-vs-promise-vs-subsidy design decision. Six new decisions await ratification in `00 RATIFICATION BRIEF` Tier F. The white paper carries the same corrections as an Evidence Base Addendum. Grade the corrected record, not the folklore.


## 4. What we are asking you to do

1. **Attack the assumptions, not the arithmetic** (the arithmetic reproduces mechanically — §2). The six standing questions per artifact: does it trust an input it doesn't control? static vs adaptive adversary? any "by construction" tells? off-protocol flanks? correlated failures? does transparency break it?
2. **Highest-value targets, in our own estimation:** the WTP anchors (§5, the single hinge), the incidence chain (`Incidence Note` — is the who-pays story complete?), the EBI methodology (basket composition governance — is the capture analysis naive?), the v16 finding (is g\*≈0.5 austerity floor the *right* contract framing?), and the consent problem (v5.4 — is the converging-floor restatement economics or hope?).
3. **Replicate hostilely:** `Replication Kit/START HERE - Reviewer Guide` has a 2-day plan; `verify_all.py` re-runs everything (python ≥3.10, numpy, scipy, matplotlib). Different numbers on your hardware is a finding we want.
4. **Deliverable we'd value most:** a memo in your voice — what's sound, what's naive, what's unfalsifiable, and what experiment or data source we haven't thought of would settle the most. Findings filed against named artifacts (file + JSON key) can be verified in minutes.

## 5. The one number to be most skeptical of

Everything revenue-side leans on **willingness-to-pay anchors** (data ~$600/contributor-yr; code $300–1,800/yr; consumer machine-pay $240/agent-yr). The friendliest literature (data-as-labor) contains the sharpest version of this attack: individual marginal data value ≈ 0. We know. A field experiment is **registered with failure defined in advance** at an order of magnitude below the anchors (`02 Landscape & Strategy/WTP Experiment Design`), and it has not run yet. If you can improve that experiment's design — or tell us it can't work — that alone justifies your fee.

## 6. What this work is not

It is **not externally reviewed** — every simulation, proof, verification pass, and this brief were produced by Anthropic models (Claude Fable 5 / Opus 4.8; per-artifact attribution is recorded as uncertain after a mid-session model switch — see the INDEX provenance note). The program's own standard is "in-family; verify, don't trust," and its two standing non-model obligations are exactly the engagement you represent: hostile out-of-family review and field evidence. It is not a forecast, not a token sale, not a policy proposal — it is a mechanism-design research program asking to be broken before anyone builds it.

## 7. Reading order (if you give it one day)

1. This file. 2. `04 Simulations/THE STORY OF THE TESTS` (the arc, no math, ~20 min). 3. The economics red-team + its scorecard (§3 above). 4. `CLAIMS REGISTER` + `ASSUMPTIONS LEDGER` (what's claimed, what it leans on). 5. Pick two sims from your own field's instincts and go to their SPEC → RESULTS → code. Day two, if granted: run `verify_all.py` and try to break something.

*Point of contact: Devan Allen (devan@ai-realized.com). Compensation, scope, and publication rights per your engagement terms; nothing in this vault is confidential from you.*
