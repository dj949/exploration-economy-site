# Claims Register — Every Headline and Its Artifact

*Each major quantitative claim in the program, its epistemic class, and the committed artifact + JSON key that backs it. A reviewer should be able to pick any row and trace the number to a file in minutes. Epistemic key (vault standard): [E] empirical · [S] closed-loop simulation · [S+] open-economy sim with registered bars + real-market anchors · [T] theory/arithmetic · [H] historical analogy · [X] speculation · [V] value judgment. Scope note: the tables through the July-9 addendum cover the **headline layer** (~50 claims, one-or-two per sim). **Extended July 11, 2026 with a second-tier (sub-headline) layer** — see the new sections at the bottom — mapping the load-bearing sub-claim bars each sim makes, each to its artifact file + specific JSON key, so a reviewer can verify not just the headline but the supporting bars. That extension adds (1) the four newest artifacts **v31–v34** (bar-level), (2) the Backlog **#4b gate-tightening re-scores** (corrected verdicts, incl. two PASS→FAIL and two downgraded to disclosed non-results, carried honestly), and (3) a representative deepening of the core sims (**v3, v5.4, v6.4–v6.7, v16**). Still not every leaf — the exhaustive per-engine reproduction index is `replication_report_verification_v4_2026-07-10.json`, and a full `verify_all.py` refresh on the owner's machine remains owed. Compiled July 9, 2026; second-tier extension July 11, 2026.*

---

## Monetary core

| Claim | Class | Artifact → key |
|---|---|---|
| Bare concept fails pessimistic earnability (survival depended on uncontrolled params) | [S] | `EVE Sim v1/results.json` (RESULTS write-up: month-16/20/74 failure timing) |
| Governor + floor + effort-weight passes all scenarios; either alone fails | [S] | `EVE Sim v2/results_v2.json` |
| Algorithm v1.0 passes harder assumptions; floor self-funded at reference calib | [S] | `EVE Sim v3/results_v3.json` |
| Concentration 62.1% / 84.4%; addictive share 17.35%; royalty flatten 53.8%/45.5% | [S] | `EVE Sim v1/results.json` (per provenance note) |
| Scale check holds to 1M agents | [S] | `EVE Sim v3/results_scale_1M.json` |

## Open economy (v6 wave) — [S+]

| Claim | Class | Artifact → key |
|---|---|---|
| Builder economy viable: 86% viability, median $392/mo at mid-anchor | [S+] | `EVE Sim v6.../results_v6_5.json` |
| Sponsored floor 26% cheaper than traditional welfare at 100% take-up | [S+] | `EVE Sim v6.../results_v6_4.json` |
| No-stranding wind-down: sponsor exit, nobody worse than never-sponsored | [S+] | `results_v6_5.json` / v6.7 |
| Median passive ceiling ~$50–70/mo across every channel | [S+] | `results_v6_*.json` |
| Demand concentration fragility: recession −84%, sponsor exit −92% | [S+] | **−92% traces**: `results_v6_7.json` → `bars.I4_dd` (=0.924); **−84% has NO committed key** (RESULTS prose only — flagged July 12, v5 D9; the committed I-bars are I0/I1/I2/I4) |
| Consumer machine-pay viable at $240 ARPU | [S+] | `results_v6_6.json` |

## Adversarial-design wave (v8–v10) — [S+]

| Claim | Class | Artifact → key |
|---|---|---|
| Static effort-weight claim dies at month 1 (3.0×) vs optimizer | [S+] | `EVE Sim v8 - Adaptive Goodhart/results*.json` |
| Outcome-linking caps optimizer at 1.32× (c_o\*≈0.71); audit inverts to 0.84× at 0.09% honest cost | [S+] | v8 results; gate-12 ratios 1.00/0.76/0.07/−0.20 |
| Endogenized c_o = 1.051 > 1 (outcome-wash converges to paying real users) | [S+] | `EVE Sim v8.1` results |
| Levered cross-venue run: canon fails (72% dd, 12 mo <1.0, attacker +$14.9M); ratified stack delivers 1.0 every month, reserve ends $28.9M | [S+] | `EVE Sim v9 - Levered Cross-Venue Run/results*.json` |
| Identity 15%-cohort breach held to 1.37% fraud, delivery 1.0; recovery owner-wins 100%; cap wall ≈22% | [S+] | `EVE Sim v10.../results_v10.json` |
| Consent: poorest floor ≥0.90 from yr 13.7, 1.0 at yr 15, zero printing, inside 6% cap; K2 failed (two-instruments relabel) | [S+] | `EVE Sim v5.4/results*.json` |

## Substrate wave (v11–v12, this era) — [S+] / [T]

| Claim | Class | Artifact → key |
|---|---|---|
| Validator safety capture costs $613M (20× v9 attacker); bribery most expensive channel | [S+] | `EVE Sim v11.../results_v11.json` → `V1` |
| Honest-pool wall H\*=5,500; registry-rot dial flat across f=0.5–25% | [S+] | `results_v11.json` → `V3` |
| Committee size load-bearing: k=101 censors 3.16%/epochs, k=201 0.483% | [T] | `results_v11.json` → `V2` |
| Civic/PoS capture-cost ratio 6.1× (safety), 19.1× post-crash | [S+] | `results_v11.json` → `V5,V6` |
| Aggregator audit break-even q\*=0.62%; honest cost 0.010% | [S+] | `EVE Sim v12.../results_v12.json` → `R1,R2` |
| Vesting load-bearing: V=0 attacker +$323k, V=168 deterred | [S+] | `results_v12.json` → `R3` |
| Blast radius at 15% cap: 0.0063% of annual mint; single-aggregator CF 1,580× | [S+] | `results_v12.json` → `R4, counterfactual` |
| Proving cost $7e-7–$0.019/claim (0.00007–1.9% of mint value) | [T] | `Benchmark - Proving Cost Envelope/results_proving_envelope.json` |
| Fee dial holds on lean route (720×), fails 6–22× at market prices | [T] | `results_proving_envelope.json` → `headline` |

## Federation (v6.8, this era) — [S+]

| Claim | Class | Artifact → key |
|---|---|---|
| Federation turns −92% single-sponsor exit into −9.9% ripple, delivery unbroken | [S+] | `results_v6_8.json` → `bars.J1_dd` |
| Gate numbers: max single-sponsor share cap\*=0.40; min escrow E\*=6mo (=step-up lag) | [S+] | `results_v6_8.json` → `bars.J3b_cap_star, J3a_E_min` |
| "26% cheaper" is peacetime (0.758); storm survivor compresses to 0.914 (J4 FAILED) | [S+] | `results_v6_8.json` → `bars.J4` (reported fail) |
| Cascades: 83% zero-months-below, 100% no stranding | [S+] | `results_v6_8.json` → `bars.J5` |

## Horizon / century (v7) — [S], asymptotic

| Claim | Class | Artifact → key |
|---|---|---|
| Generational floor crossover yr 65 (maintenance-conditional) | [S/X] | `EVE Sim v7.../results_v7.json` |
| Growth 1.5%/yr quality-adjusted, converts to free time at physical cap | [S/X] | `results_v7.json` |
| Reward gradient fails "healthy" band on equality side (top10/median 2.7×) | [S] | `results_v7.json` |

## Provisional / not-yet-run (do NOT cite as results)

| Claim | Class | Status |
|---|---|---|
| Ecology: EDEN delivery 1.0 vs GDP-coupled ≈0 under supply shocks; inflates to do it | [S, PROVISIONAL] | `EVE Sim v13 - Ecology/results_v13.json` — **E0 gate failed; root-caused (floor-printing spiral + unfunded floor = v5.2 mismatch); funding rebuild owed; still not citable** |

## Addendum — runs completed after this register was first compiled (July 9 evening; rows verified by the v3 pass)

| Claim | Class | Artifact → key |
|---|---|---|
| Oracle 2-of-3 capture costs $99.5M; cheapest pair R+M | [S+] | `EVE Sim v13 - Oracle Capture & Quarantine/results_v13_oracle.json` → `O1` |
| Oracle extraction can't pay: 80× cost/payoff, ROI −$98M (sabotage-only) | [S+] | `results_v13_oracle.json` → `O2` |
| Granted free capture, floor delivers 0.960 centrally; 0.888 under pessimistic triple-combo (**O3c FAIL**, re-validation speed load-bearing) | [S+] | `results_v13_oracle.json` → `O3` |
| Lane dearest class at $310M but 4.26× reporters, under 5× bar (**O4 FAIL**) | [S+] | `results_v13_oracle.json` → `O4` |
| Single-CPI oracle capturable at 1/995 the cost; unbonded crowd 1/199 | [S+] | `results_v13_oracle.json` → `O5` |
| Composition discount: joint $483M vs $737M sum (ratio 0.66) — X1 fails as registered | [S+] | `EVE Sim v14 - Cross-Layer Composition/results_v14.json` → `X1` |
| Identity blast radius composes 1.37% → 3.74%, past 2% gate (X2); joint 15% cross-layer cap restores 0.96% (X4) | [S+] | `results_v14.json` → `X2, X4` |
| Oracle→reserve loop: delivery ≥1.0 but reserve drains in 4.0 months (X3) | [S+] | `results_v14.json` → `X3` |
| Governance: √-weighting squashes 30%-whale to ~1.1%; majority needs ~1,595 colluders | [S] | `EVE Sim v15 - Governance Capture/results_v15.json` → `G1, G2` |
| Single-pass cap leaks to 9.4% under concentration; iterative water-filling holds 5.00% (F1 → spec v0.2) | [S] | `results_v15.json` → `G1.extreme` |
| Identity-splitting pays √k raw (1.41× at k=2); closed only by ~120F/identity — governance inherits the identity keystone | [S] | `results_v15.json` → `G4` |

---

# Second-tier claims — sub-headline bars and their artifact keys (added July 11, 2026)

*Extends the register past the headline layer (Backlog #20). Each row below is a **supporting bar** an economist would check next, mapped to a committed file + a specific JSON key. Every key here was opened and confirmed against the committed `results_v*.json` on July 11, 2026; the per-engine reproduction of those files is attested in `replication_report_verification_v4_2026-07-10.json` (and v3 for the earlier sims). Failures and downgrades are carried honestly — they are exactly what a skeptic wants mapped. One claim that does **not** trace to a committed key is flagged inline (v6.5 median-builder $392). File paths are relative to each sim's own folder under `04 Simulations/`.*

## New artifacts not previously in the register — v31–v34

**v31.0 Austerity Floor & Escrow** (`EVE Sim v31 .../results_v31.json`) — headline: a 0.60 austerity floor holds delivery in both seeds at the committed 6-mo escrow, while a 0.50 floor breaches at *every* swept escrow depth (escrow is inert against austerity).

| Claim | Class | Artifact → key |
|---|---|---|
| AB2 candidate A priced & clean — floor 0.60 @ escrow 6: 0 months below in both seeds (troughs 1.088 / 1.062) | [S+] | `results_v31.json` → `AB2.pass`, `AB2.cells.7/11.p10_min42` |
| AB3 candidate B is dead — no swept escrow depth (6/9/12 mo) holds a 0.50 floor for both seeds | [S+] | `results_v31.json` → `AB3.min_escrow_holding_both` (=null), `AB3.pass` |
| AB1 frontier monotone — deeper escrow never worsens; escrow's effect on austerity ≈ 0 | [S+] | `results_v31.json` → `AB1.pass`, `AB1.violations` (=[]) |
| AB4 below the floor — no escrow rescue at 0.45 (11–12 months below at every depth) | [S+] | `results_v31.json` → `AB4.any_rescue` (=false) |
| AB0 regression anchor — E=6 column reproduces v16's committed isolation slices, both seeds | [S+] | `results_v31.json` → `AB0.pass` |
| AB5 no-print invariant — 0 EVE printed across all 24 cells | [S+] | `results_v31.json` → `AB5.max_printed` (=0.0) |

**v32.0 Payer-Exit Re-balancing** (`EVE Sim v32 .../results_v32.json`) — headline: a departed payer's hole can't be billed to the remaining rich (RB1 fails), but is closed cheaply by tapering the subsidy; reserve size buys phase-in time.

| Claim | Class | Artifact → key |
|---|---|---|
| RB0 anchor — post-exit gap $3,006.6M/mo; reserve runways 24 mo (committed) / 9 mo (registered) | [S+]/[T] | `results_v32.json` → `RB0.gap_musd_mo`, `RB0.runway_committed`, `RB0.runway_registered` |
| RB1 slice-bump alone **FAILS** (pre-registered) — needs +80.2% of givers' burden vs the 6% political bar | [S+]/[T] | `results_v32.json` → `RB1.bump_needed_frac_of_existing_burden` (=0.802), `RB1.pass` (=false) |
| RB2 taper alone — 44.5% cut closes the gap; drawer delivery 0.953 (never-joined baseline 0.894) | [S+]/[T] | `results_v32.json` → `RB2.taper_frac_closing_gap`, `RB2.drawer_delivery` |
| RB3 mixed (6%-capped bump + taper) — 41.2% taper, drawer delivery 0.956 | [S+]/[T] | `results_v32.json` → `RB3.taper_frac`, `RB3.drawer_delivery` |
| RB4 phase-in window — 18 mo (registered $36B) vs 48 mo (committed $81.1B): +30 mo diplomacy runway | [S+]/[T] | `results_v32.json` → `RB4.max_phase_in_months_registered`, `RB4.max_phase_in_months_committed` |
| RB5 no-print + conservation — 0 printed; drain = gap·(M+1)/2 exact | [S+]/[T] | `results_v32.json` → `RB5.printed`, `RB5.drain_vs_closed_form_ok` |

**v33.0 Index Drift** (`EVE Sim v33 .../results_v33.json`) — headline: the 0.05 measurement-bias budget lasts ~a decade, then a systematic drift exhausts it; the two ±5% sides fail on wildly different clocks, so the reserve (over-read) side is the binding constraint on re-basing.

| Claim | Class | Artifact → key |
|---|---|---|
| ID0 sanity — zero drift ⇒ delivery 1.10 flat, over-pay $0, reserve $36M | [T]/[S] | `results_v33.json` → `ID0.pass` |
| ID1 under-read **FAILS** (headline, as registered) — 0.05 budget exhausted yr 9.33; essentials breached yr 19.08; yr-50 delivery 0.856 | [T]/[S] | `results_v33.json` → `ID1.budget_exhaust_year`, `ID1.essentials_breach_year`, `ID1.real_delivery_year50`, `ID1.pass` (=false) |
| ID2 over-read **FAILS** — finite $36M reserve drained in 2.50 yr; $16.2B over-paid by yr 50 | [T]/[S] | `results_v33.json` → `ID2.reserve_drain_year`, `ID2.cum_over_pay_year50_billion`, `ID2.pass` (=false) |
| ID3 re-basing split **FAIL** — binding cadence 2.5 yr (reserve side); canon 5 yr is delivery-safe but reserve-unsafe | [T]/[S] | `results_v33.json` → `ID3.binding_interval_yr`, `ID3.canon_delivery_safe` (=true), `ID3.canon_reserve_safe` (=false), `ID3.pass` |
| ID4 determinism + honest-noise — deterministic ✓, zero-mean noise absorbed 50 yr ✓; ±3-mo cross-seed agreement clause **FAILS** (110 vs 123 mo) | [T]/[S] | `results_v33.json` → `ID4.honest_noise_absorbed_50yr` (=true), `ID4.seeds_agree_within_3mo_and_near_det` (=false), `ID4.pass` |

**v34.0 Baumol Governor Drift** (`EVE Sim v34 .../results_v34.json`, on the v7 Horizon chassis) — headline: the aggregate-tuned governor is blind to Baumol and over-mints against the slow sector, but the essentials-indexed *floor* protects recipients regardless; two published FAILs come with the fix.

| Claim | Class | Artifact → key |
|---|---|---|
| BM0 regression anchor — Baumol OFF reproduces v7 crossover (784/764 mo, seeds agree); gap-0 drift 0 | [S/X] | `results_v34.json` → `bars.BM0_pass`, `bars.BM0_v7_seed7_crossover_mo`, `bars.BM0_v7_seeds_agree` |
| BM1 governor drift — aggregate-tuned governor over-mints: essentials end 3.74× (agg) vs 2.17× (ess-tuned) = 1.72× drift | [S/X] | `results_v34.json` → `bars.BM1_drift_factor`, `bars.BM1_Pslow_end_agg`, `bars.BM1_overmint` |
| BM2 does it break the floor? **FAIL** (informative) — delivery holds 1.10 (drift absorbed) but Baumol delays generational crossover yr 46→92 | [S/X] | `results_v34.json` → `bars.BM2_delivery_index_min_agg` (=1.1), `bars.BM2_crossover_mo_gap0` (=551), `bars.BM2_crossover_mo_agg` (=1102), `bars.BM2_pass` (=false) |
| BM3 EBI-indexed floor protects (load-bearing **PASS**) — rel-price 7.36×; EBI floor delivers 1.10 throughout; an aggregate-CPI floor breaches 1.0 at yr 8.8, collapses to 0.20× by yr 100 | [S/X] | `results_v34.json` → `bars.BM3_rel_price_end`, `bars.BM3_ebi_delivery_min`, `bars.BM3_cpi_below1_year`, `bars.BM3_cpi_delivery_end`, `bars.BM3_pass` |
| BM4 governor fix **FAIL**→constructive — ess-tuned governor cuts drift 62% but `c_min` pins it; ess-index + subsidy sunset drives residual drift to 0 | [S/X] | `results_v34.json` → `bars.BM4_drift_reduction`, `bars.BM4_full_fix_works` (=true), `bars.BM4_rel_drift_reduction` (=1.0), `bars.BM4_pass` (=false) |

## Backlog #4b gate-tightening re-scores (corrected verdicts, July 11)

*Source: `04 Simulations/GATE-TIGHTENING PASS - Backlog 4b Executed (July 2026).md` + the "gate-tightening EXECUTED" footers on each RESULTS. Physics unchanged (byte-identical cores); only gate scoring was recoded to compute the registered clause. Two bars went PASS→FAIL, two are now disclosed non-results.*

| Claim | Class | Artifact → key |
|---|---|---|
| v18 Y4 **PASS→FAIL** — recoded τ-frontier is degenerate: τ*=5%, refuting the registered ~2–3% (excess-drain τ-invariant) | [S+] | `results_v18.json` → `Y4.pass` (=false), `Y4.tau_star` (=0.05), `Y4.registered_expectation_tau_star_2_3pct` (=false) |
| v18 Y1/Y2 recoded, still PASS — Y2 now scores the registered 3×~4-mo (=12-mo) baseline; cross-check extends drain 2→24 mo | [S+] | `results_v18.json` → `Y2.pass`, `Y2.months_to_drain_xc_on` (=24), `Y2.registered_bar_months` (=12) |
| v18 Y0 **PASS→FAIL (v5 re-score, July 12)** — scored across the full registered σ_xc sweep {0.5%,1%,2%} instead of the central dial only: 12.5% false-quarantine months at σ=2% vs the 5% bar, seeds disagreeing there; monotonicity/seeds clauses vacuous at δ=0 (disclosed diagnostics) | [S+] | `results_v18.json` → `Y0.pass` (=false), `Y0.registered_sigma_sweep.0.02.false_quar_rate` (=0.125), `Y0.clause1_rate_lt_5pct_all_registered_sigma` (=false) |
| v21 K4 **PASS→FAIL** — re-balancing meets consent under the measured 25% bar but not the registered 6% political bar; "closes ≤24 mo" is a disclosed non-result | [S+] | `results_v21.json` → `K4_payer_exit_rebalance.pass` (=false), `.consent_met_under_political` (=false), `.closes_within_24mo_not_computed_reduced_form` |
| v21 K2 recoded, still PASS — 2-of-2 oracle cost $409.5M = sum of the two independent captures (4.12× single-channel); delivery dip 1% | [S+] | `results_v21.json` → `K2_two_of_two_oracle.pass`, `.two_of_two_cost`, `.cost_multiple_vs_single` |
| v26 Q5 **downgraded** — freedom-tradeoff gate still PASS but its contract-freedom sub-term is owner-stipulated, not computed | [S] | `results_v26.json` → `Q5.fully_computed` (=false), `Q5.contract_freedom.stipulated_not_computed` (=true), `Q5.pass` |
| v26 Q4 recoded & PASS — FREE regime = fastest lender accumulation; conservation residual ~2e-7 holds | [S] | `results_v26.json` → `Q0.conservation_ok`, `Q4.FREE_fastest_accumulation` |
| v26 Q0 **PASS→FAIL (v5 re-score, July 12)** — the unqualified registered seeds-agreement clause, scored over ALL reported metrics, is breached by the two small-count tail statistics (trap_rate ~11–14%, top-1% lender share ~17.9%); structural aggregates all <2%, headlines seed-averaged and unaffected; aggregate-subset re-registration queued as an owner decision | [S] | `results_v26.json` → `Q0.pass` (=false), `Q0.seeds_agree_all_reported_metrics` (=false), `Q0.max_all_metric_seed_spread`, `Q0.seed_spread_all_metrics` |
| v28 SB2 **PASS→disclosed non-result** (`pass: null`) — detection TP/FP are assumed dials, not measured | [S] | `results_v28.json` → `SB2.pass` (=null), `SB2.detection_assumed_not_measured` (=true), `SB2.computed` (=false) |
| v28 SB0 now computes money-supply conservation — residual 0 across the reserve-ratio sweep | [S] | `results_v28.json` → `SB0.conservation_holds`, `SB0.max_abs_residual` (=0.0), `SB0.pass` |
| v25 N0 now computed — fractional-reserve multiplier verified by *simulated* re-lending cascade (residual ~3.5e-15); full/full-lock control ratio 1.0, FRAC breaches all | [S]/[T] | `results_v25.json` → `N0.pass`, `N0.frac_multiplier_identity.*.sim_residual`, `N1.full_control_ratio`, `N1.frac_breaches_all` |
| v25 N3 now computed (disclosed static frame) — full reserve survives 100% withdrawal; dynamic run not simulated | [S]/[T] | `results_v25.json` → `N3.full_survives_100pct` (=true), `N3.dynamic_run_simulated` (=false), `N3.pass` |

## Core-sim deepening — headline → load-bearing sub-claims

### Monetary core — v3 (`EVE Sim v3/results_v3.json`)

| Claim | Class | Artifact → key |
|---|---|---|
| The floor is load-bearing — the no-floor variant fails commoditization & combined (first breach mo 74, longest 107 mo) | [S] | `results_v3.json` → `verdicts["v3-nofloor\|commoditization\|conservative"]` → `.fails`, `.first`, `.longest` |
| Floor self-funded at reference calib — zero top-up minting; floor cost ≤2.2% of flow | [S] | `results_v3.json` → `verdicts["v3-full\|combined\|conservative"].topup_max` (=0.0), `.floor_cost_max` (=2.2) |
| Bare concept (no floor, no algorithm) inflates ~960% | [S] | `results_v3.json` → `verdicts["v3-bare\|baseline\|conservative"].infl` (=9.6) |
| Full algorithm passes all 10 scenario×demand cells — combined stress is a 1-mo dip within the 3-mo criterion | [S] | `results_v3.json` → `verdicts["v3-full\|combined\|conservative"].fails` (=false), `.longest` (=1) |

### Consent & federation — v5.4 (`EVE Sim v5.4 .../results_v54.json`)

| Claim | Class | Artifact → key |
|---|---|---|
| K0 calibration anchor — insurance take-up peak 45.9%, yr-15 18.9%, obligations fall 61.5% | [S+] | `results_v54.json` → `K0_validation.PASS` |
| K3 membership equilibrium — rich-region value/cost 1.6×, value>cost in 100% of region-years | [S+] | `results_v54.json` → `K3_membership_equilibrium.median_value_over_cost`, `.PASS` |
| K4 federation fallback — poorest local-only strength 0.10→0.433 by yr 15, no collapse, zero printing | [S+] | `results_v54.json` → `K4_federation_fallback.poorest_local_only_strength_yr15`, `.PASS` |
| K5a counterfactual (why the discipline matters) — "print the gap" drops delivery <1.0 within 1 month, 0.148 by yr 15 | [S+] | `results_v54.json` → `K5a_print_the_gap.CONFIRMED`, `.delivery_yr15` |
| K2 insurance legitimacy **FAILS** (already headlined) — both-roles 50% / 52.5% vs the 67% bar | [S+] | `results_v54.json` → `K2_insurance_legitimacy.PASS` (=false) |

### Open economy — v6.4–v6.7 (`EVE Sim v6 .../results_v6_*.json`)

| Claim | Class | Artifact → key |
|---|---|---|
| **v6.4** F5 "26% cheaper than welfare" (headline key) — net $365/enrollee vs traditional $494 = 26.05% saving | [S+] | `results_v6_4.json` → `bars.F5_saving_vs_trad` (=0.2605), `bars.F5_net_per_enrollee`, `bars.F5_trad_per_enrollee` |
| **v6.4** F1 floor holds with zero printing — effective p10 min 1.366, printed 0 | [S+] | `results_v6_4.json` → `bars.F1_pass`, `bars.F1_print` (=0.0) |
| **v6.4** F3 governor cuts cycle drawdown — 9.5% (gov) vs 38.7% (no-gov) | [S+] | `results_v6_4.json` → `bars.F3_cycle_dd_gov_nogov`, `bars.F3_pass` |
| **v6.4** F2 taper-cliff **FAILS**; F4 job-shock recovery **FAILS** | [S+] | `results_v6_4.json` → `bars.F2_pass` (=false), `bars.F4_pass` (=false) |
| **v6.5** G2 open-source viability — 86% of builders ≥$200/mo (mid-anchor) | [S+] | `results_v6_5.json` → `bars.G2_share_b200` (=0.854), `bars.G2_pass` |
| **v6.5** "median builder $392/mo" — **NO committed JSON key** (RESULTS prose only; the keyed viability figure is `bars.G2_share_b200`) | [S+] | `results_v6_5.json` → *prose-only; not a committed scalar key — flagged* |
| **v6.5** G1 median participant **FAILS** — overall median $41/mo vs the $75 bar (the median is still not a builder) | [S+] | `results_v6_5.json` → `bars.G1_med_y8` (=40.5), `bars.G1_pass` (=false) |
| **v6.5** G3 builder economy grows 2.46×; G4 cap lowers gini (0.345 vs 0.362); G5 machine-pay ARPU-to-move-median **FAILS** | [S+] | `results_v6_5.json` → `bars.G3_growth`, `bars.G4_gini_cap`/`G4_gini_nocap`, `bars.G5_pass` (=false) |
| **v6.6** H2 viability ratio — median earn $51 vs $20 spend = 2.55× (the "$240 ARPU viable" headline) | [S+] | `results_v6_6.json` → `bars.H2_ratio`, `bars.H2_pass` |
| **v6.6** H4 p10 fiat-net positive $129.9/mo; H1 median-at-c240 bar **FAILS** ($51.7/mo) | [S+] | `results_v6_6.json` → `bars.H4_pass`, `bars.H1_med_y8_c240`, `bars.H1_pass` (=false) |
| **v6.7** I4 sponsor-exit drawdown 92.4% (the "−92%" headline), reserve only 2.44 mo at exit — **FAIL**, no recovery | [S+] | `results_v6_7.json` → `bars.I4_dd` (=0.924), `bars.I4_pass` (=false), `bars.exit_reserve_months_at_exit` |
| **v6.7** I2 payer-stress **FAILS** (p10 min 0.662); I1 austerity holds (p10 1.001); I0 steady holds (p10 1.36) | [S+] | `results_v6_7.json` → `bars.I2_pass` (=false), `bars.I1_pass`, `bars.I0_pass` |

### Regime-shift envelope — v16 (`EVE Sim v16 .../results_v16.json`, new to the register)

| Claim | Class | Artifact → key |
|---|---|---|
| L2 storm exit, lag ≤6 **FAILS** (the run's headline) — only 47.4% of the envelope (18/38) holds delivery | [S+] | `results_v16.json` → `bars.L2_frac_hold_lag_le6` (=0.474), `bars.L2_pass` (=false) |
| L1 peacetime exit, lag ≤6 — 100% (38/38) hold, zero printing | [S+] | `results_v16.json` → `bars.L1_frac_hold_lag_le6` (=1.0), `bars.L1_pass` |
| L1 bracket (lag >6) failed-to-fail (F1) — 0 breaches in 26 cells | [S+] | `results_v16.json` → `bars.L1_bracket_lag_gt6_breaches` (=0), `bars.L1_bracket_as_registered` (=false) |
| L3 governance containment — 100% contain across 400 cells; min cartel×κ 2.02; single-pass leak 7.75% | [S] | `results_v16.json` → `bars.L3_contain_pass`, `E_B.min_cartel_x_kappa`, `E_B.singlepass_leak_fraction` |
| L4 committee censorship k=201 — ≤1%/epoch for attacker share ≤25% (measured s\*=28%) | [S]/[T] | `results_v16.json` → `bars.L4_pass` |
| Austerity-floor sustained-breach bracket (feeds v31 / v6.8) — no sustained breach at floor ≥0.50 (s7) / ≥0.60 (s11); breach at 0.45 | [S+] | `results_v16.json` → `isolation.g_star_bracket_3consec_s7`, `isolation.g_star_bracket_3consec_s11` |

---

*Machine-checked upgrade (July 9, evening): the [T]-class rows — committee-size censorship (k=101/201), the splitting/cartel arithmetic, the taper no-cliff property, and the O0 harness formula — are now backed by symbolic/exact-rational derivations in `Proofs - Machine-Checked Theory Claims (July 2026)` (**10/10 PROVED as of the July 9 late pass, reconciled July 11** — P8 at self-consistency grade after the envelope was rewritten to emit its derivation, values unchanged; P9/P10 added by same-evening registered addendum; P3 re-scored July 11 to its registered clauses incl. the uniqueness check; this footer previously carried the stale 7/8). Reproduction status: original ledger `replication_report.json` (44/52 at 17:00, before the addendum rows' engines existed); **superseding coverage: `replication_report_verification_v3_2026-07-09.json`** (54 engines, 49 REPRODUCE, all exceptions explained — including every addendum row's engine) plus independent from-scratch re-executions of all five July-9 sims (see vault root `VERIFICATION v3`). Retired claims (not in this register by design) are in the white-paper changelog. Compiled July 9, 2026; addendum by the v3 verification pass the same day; proofs footer + coverage line updated by the v4 pass July 10–11. **Coverage note (July 10–11):** no committed harness ledger yet covers v16–v30 — the v4 pass re-executed every one of them engine-by-engine in isolation (byte-identical JSONs + figures throughout; ledger filed as `replication_report_verification_v4_2026-07-10.json`), and a plain `verify_all.py` run on the owner's machine remains the owed full-vault refresh. Model attribution note: session signatures are unreliable per the mid-session Fable 5 → Opus 4.8 switch recorded in the INDEX (extended July 11 through the v16–v30 window; v23 = Fable 5 per the owner's record). In-family; verify, don't trust.*
