# Assumptions Ledger — Every Dial a Skeptic Should Attack

*The consolidated soft-spots map. Every result in this program is "existence-and-shape under stated dials, not a forecast." This ledger collects the dials that carry the most weight, what leans on each, and what breaks if it's wrong — so a reviewer can find the tender places in ten minutes. Grouped by theme, ranked within group by how much rides on them. Compiled July 9, 2026 from the "honest limits" sections of every SPEC and RESULTS.*

---

## 1. Identity & attestation — THE KEYSTONE (attack here first)

| Dial | Central value | What leans on it | What breaks if wrong |
|---|---|---|---|
| **Liveness efficacy** `p_live` (prob. a stolen credential defeats liveness/session) | 0.05–0.20 | v10 recovery race, v11 sortition integrity, v12 claim validity | If liveness is cheaply beaten, sortition runs over sock-puppets, the floor is farmable, and every mint number is soft. **This is the single load-bearing assumption in the whole program.** |
| **Attestation forgery cost / blast radius** (gate 9) | assumed costly; blast radius *unmeasured* | v12 (forged claims assumed free to the attacker), PoE pipeline | v12 explicitly prices attacks *after* forgery, spotting the attacker forged attestations for free. If forgery is cheap AND wide, minting integrity fails upstream of every audit. |
| **Registry fraud rate** `f` | 2% (swept to 25%) | v11 validator capture | v11 found budget flat across f — so this one is *less* load-bearing than expected (the honest-pool size H matters more). Good news, but verify. |
| **Lifetime-identity cost** | ~120F ($72k) | anti-sybil economics everywhere | If a verified identity is cheaper to manufacture, farming/validation/aggregation attack costs all fall proportionally. |
| **120F / bond prices EBI-real (don't crash with token)** | assumed | v11 crash-independence (19.1× post-crash) | If identity cost is token-denominated, security becomes pro-cyclical like PoS. |

## 2. Willingness-to-pay — THE HINGE (no sim can supply this)

| Dial | Central value | What leans on it | What breaks if wrong |
|---|---|---|---|
| **Institutional WTP for data** | $600 ARPU | floor funding, data-dignity layer | Near-zero WTP collapses the economic case to a niche. **The true go/no-go; a field experiment, not a sim.** |
| **Institutional WTP for code/software** | $300–1,800 capture | builder economy (86% viability, $392/mo) | The builder wedge — EDEN's strongest [S+] result — evaporates if code capture is near zero. |
| **Consumer machine-pay** | $240/agent-yr | v6.6 consumer channel | Softens or removes the consumer demand base. |
| **Use-value coefficient** | $3/hr | crash-proof shadow income, poverty results | The one behavioral number that moves poverty outcomes; EdenQuest can measure it. |

## 3. Market & macro anchors — [S+] foundations

| Dial | Central value | What leans on it | What breaks if wrong |
|---|---|---|---|
| Essentials basket / floor F | $600/mo; F=1.10 | every delivery bar (p10 ≥ 1.0) | The unit the whole floor is denominated in; regional/temporal variance untested. |
| Mint value per verified hour | $5/hr | v12 blast-radius, proving-cost fraction | Scales attacker payoffs and cost fractions linearly. |
| Leakage elasticity (off-ledger flight at high slices) | ~half of commerce off-ledger at 25% slice | jurisdiction-slice guidance ≤15–20% | If elasticity is higher, the White Box "darkness ceiling" is lower and slice revenue is thinner. |
| FX / thin-market amplification | v6 stylization, N=20k | all open-economy drawdowns | Real markets are deeper *and* more reflexive; direction of error unclear. |

## 4. Behavioral & political — dials, explicitly not forecasts

| Dial | Central value | What leans on it | What breaks if wrong |
|---|---|---|---|
| Sponsor exit hazard / contagion | 15%/election, ×2 contagion | v6.8 federation, cascade tail | Nobody knows the real hazard of elections defunding a floor; the cascade tail (20 mo below in worst draw) widens if higher. |
| **No accession** (lapsed sponsor tranches never re-tendered) | assumed | v6.8 long-run coverage | Conservative — real federations replenish (Gavi-style), so v6.8 coverage numbers are *floors*. |
| Austerity depth | cut to 60% in recession | v6.8 storm | Deeper austerity pushes the designed-thin storm margin under water. |
| Effort-classification `W_effort` | 0.3× passive weight | retired as defense (v8) | Already retired; do not attack as if load-bearing. |
| Consent bar / net-contribution cap | 6% of regional mint | world floor (v5.4) | Political, unsimulatable; the convergence story assumes regions change places (v5.4 K2 failed here). |

## 5. Mechanism / engineering dials (this era)

| Dial | Central value | What leans on it | What breaks if wrong |
|---|---|---|---|
| Honest validator pool H | 20,000 (wall at 5,500) | v11 safety | Below ~5,500, bond-only capture undercuts the v9 attacker — **monitor live like reserve months**. |
| Committee size k | 201 | v11 censorship | k=101 fails the censorship bar (3.16%); k is a real security parameter. |
| Cohort caps (registrar/jurisdiction/hosting/client/aggregator/TEE-vendor) | ≤15% | v11, v12, identity blast radius | The single most reused defense in the architecture; if a cohort exceeds it undetected, correlated failure returns. |
| Payout vesting window V | 168 epochs (7 days) | v12 aggregator deterrence | V=0 lets smash-and-grab profit (+$323k); the window is load-bearing. |
| Re-aggregation audit rate q | ≥1% (break-even 0.62%) | v12 | Below break-even, laundering turns profitable. |
| Proving cost / device key format | lean circuit; circuit-friendly keys | proving-cost envelope, fee dial | TEE-native P-256 in-circuit costs ~200×, breaks hourly epochs — a conformance choice, not a detail. |
| Proof-system marginal cost | GPU $1–4/hr dial; vendor throughput claims | proving envelope | Desk benchmark only; a real hardware bench is a launch gate. |

## 6. Model-class caveats (true of everything here)

- **In-family.** All engines AI-built, AI-reviewed. The reproduction harness makes this checkable, not resolved.
- **Calculator/ABM grade.** Most sims are closed-form or light agent models, not general-equilibrium; N typically 20k, one region.
- **Static-ish adversaries** except where explicitly adaptive (v8). Real attackers adapt across all of them.
- **Zero coordination cost** granted to attackers in several sims (v11, v12) — pessimistic in the defense's favor, stated.
- **PROVISIONAL v13-Ecology**: E0 harness gate failed, engine unvalidated — do not treat its dials as load-bearing until reviewed.

---

*The fastest hostile read: pick one dial from §1 or §2, find every result that leans on it (this table names them), and ask whether the real-world value could be off by the factor that flips the result. That is the attack the program most needs and least can run on itself. Compiled by Claude Fable 5, July 9, 2026.*
